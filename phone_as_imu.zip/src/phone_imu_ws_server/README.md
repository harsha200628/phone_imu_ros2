# Phone IMU ROS 2 Server

A high-performance ROS 2 system that streams real-time IMU data (Orientation, Acceleration, Angular Velocity) from a mobile phone into a ROS 2 environment via WebSockets.

![Cyber-IMU Visualization](https://img.shields.io/badge/ROS2-Humble/Jazzy-blue)
![Architecture](https://img.shields.io/badge/Architecture-Asyncio/RCLPY-green)

## 🚀 Overview

This package allows you to use your smartphone as an external IMU sensor for your ROS 2 projects. It features a stunning, mobile-optimized glassmorphism web dashboard that captures sensor data and a robust Python backend that bridges it to standard ROS 2 topics and TF transforms.

## ✨ Key Features

- **🌐 WebSocket Integration**: Fast, low-latency data streaming using `asyncio` and `websockets`.
- **📱 Cyber-Dashboard**: A premium web interface with real-time diagnostics and orientation display.
- **📐 3D Visualization**: Includes a URDF model and RViz setup to mirror phone movement.
- **⚙️ Clean Architecture**: Separated threading for `rclpy` spinning and `asyncio` events to prevent loop conflicts.
- **🛠️ Mock Mode**: Test your ROS 2 pipeline without physical hardware.

## 🛠️ Installation

### Prerequisites
- ROS 2 (Humble or newer)
- Python 3 with `websockets`
  ```bash
  pip install websockets
  ```

### Build
```bash
# In your ROS2 workspace
colcon build --packages-select phone_imu_ws_server
source install/setup.bash
```

## 🚀 Usage

### 1. Launch Visualization & Server
```bash
ros2 launch phone_imu_ws_server visualize.launch.py
```

### 2. Connect Your Phone
- The terminal will display your computer's IP address (e.g., `http://192.168.1.5:8080`).
- Open this URL on your phone's browser.
- Tap **"Initiate Link"** to start streaming.

## 📊 Published Topics

| Topic | Type | Description |
| :--- | :--- | :--- |
| `/phone_imu` | `sensor_msgs/Imu` | Real-time IMU data (Quaternion, Accel, Gyro) |
| `/tf` | `tf2_msgs/TFMessage` | Dynamic transform from `odom` to `base_link` |

## 📐 Hardware Description (URDF)
The virtual representation is a high-visibility, vibrant red smartphone model scaled to `0.32m x 0.16m x 0.02m` for easy tracking in 3D space.

## 📝 License
This project is licensed under the Apache-2.0 License.
